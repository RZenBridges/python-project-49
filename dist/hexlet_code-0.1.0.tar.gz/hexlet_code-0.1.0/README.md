### Hexlet tests and linter status:
[![Actions Status](https://github.com/RZenBridges/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/RZenBridges/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/ad329d829d0660db4393/maintainability)](https://codeclimate.com/github/RZenBridges/python-project-49/maintainability)

From the project root run the installation command <make package-install>

See examplary installation: https://asciinema.org/a/tjS7nT0kCqvyKxDfZFU6GfRNM
